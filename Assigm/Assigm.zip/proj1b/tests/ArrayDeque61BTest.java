import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

class ArrayDeque61BTest {

    private ArrayDeque61B<Integer> deque;

    @BeforeEach
    void setUp() {
        deque = new ArrayDeque61B<>();
    }

    @Test
    void testAddFirstAndRemoveFirst() {
        deque.addFirst(1);
        deque.addFirst(2);
        assertEquals(2, deque.size());
        assertEquals(2, deque.removeFirst());
        assertEquals(1, deque.removeFirst());
        assertTrue(deque.isEmpty());
    }

    @Test
    void testAddLastAndRemoveLast() {
        deque.addLast(1);
        deque.addLast(2);
        assertEquals(2, deque.size());
        assertEquals(2, deque.removeLast());
        assertEquals(1, deque.removeLast());
        assertTrue(deque.isEmpty());
    }

    @Test
    void testMixedOperations() {
        deque.addFirst(1);
        deque.addLast(2);
        deque.addFirst(0);
        assertEquals(3, deque.size());
        assertEquals(0, deque.removeFirst());
        assertEquals(2, deque.removeLast());
        assertEquals(1, deque.removeFirst());
        assertTrue(deque.isEmpty());
    }

    @Test
    void testToList() {
        deque.addLast(1);
        deque.addLast(2);
        deque.addLast(3);
        List<Integer> list = deque.toList();
        assertEquals(List.of(1, 2, 3), list);
    }

    @Test
    void testGet() {
        deque.addLast(1);
        deque.addLast(2);
        deque.addLast(3);
        assertEquals(1, deque.get(0));
        assertEquals(2, deque.get(1));
        assertEquals(3, deque.get(2));
        assertNull(deque.get(3));
    }

    @Test
    void testResize() {
        for (int i = 0; i < 10; i++) {
            deque.addLast(i);
        }
        assertEquals(10, deque.size());
        for (int i = 0; i < 10; i++) {
            assertEquals(i, deque.get(i));
        }
    }

    @Test
    void testEmptyDeque() {
        assertTrue(deque.isEmpty());
        assertNull(deque.removeFirst());
        assertNull(deque.removeLast());
    }
}